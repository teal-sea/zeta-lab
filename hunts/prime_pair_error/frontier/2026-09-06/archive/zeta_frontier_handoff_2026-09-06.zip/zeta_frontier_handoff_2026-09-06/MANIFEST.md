# Zeta frontier handoff — 2026-09-06

Purpose: lossless preservation of the mathematical work produced in this conversation before the next agent phase.

## Canonical repository

The public scientific source of truth is `teal-sea/zeta-lab`.

Current relevant repository state observed during handoff:
- PR #181 merged: CHHL Table 1 replication / first prime-pair-error pass.
- PR #186 merged: residue-class correction / mod 1, 3, 30 pass.
- PR #188 merged: Wronskian / character-weighted third pass.
- PR #189 closed unmerged: independent referee repairs for the third pass. Preserve its report/corrections explicitly; do not assume they are on `main`.
- PR #191 merged: `hunts/prime_pair_error/UPPER_BOUND.md`, total-error upper-bound attempt.
- Current `hunts/prime_pair_error/` on main contains `MISSION.md`, `RESULTS.md`, `RUNS.md`, `UPPER_BOUND.md`, `probe.py`, `residue.py`, `wronskian.py`, and the saved result JSONs.

## Conversation artifacts in this bundle

### 1. `prime_reverse_engineering_bundle.zip`
Status: NOT known to be committed to Zeta Lab as a standalone artifact.
Contents: the original reverse-engineering experiment, exact-next-gap models, pair-frequency recovery, holdouts, trillion-scale stress test, notebook, validation.
Scientific grade: executed computational experiment; pair-frequency search recovered known Hardy-Littlewood structure, no novelty claim.
Recommended destination: preserve as its own bounded hunt or archived precursor; do not mix its claims into the later analytic upper-bound proof.

### 2. `prime_mobius_review_bundle.zip`
Status: NOT known to be committed.
Contents: independent Möbius-grouping checks, matching obstruction, next-experiment brief.
Scientific grade: exact/checkable deductions plus bounded computations; no RH result.
Recommended destination: separate hunt (`mobius_boundary_cancellation` or equivalent), NOT inside `prime_pair_error`.

### 3. `prime_pair_q3_followup.zip`
Status: much of this direction was subsequently re-derived/integrated by PR #186.
Contents: independent modulo-3 derivation/checker and period-6 decomposition.
Recommended destination: archive as provenance/precursor; avoid duplicating canonical PR #186 code unless a comparison note is useful.

### 4. `zero_energy_feasibility.zip`
Status: NOT committed.
Contents: `FEASIBILITY.md`, zero-additive-energy transfer for an exponentially smoothed annulus, sharp q=1 localization obstruction, failed absolute-value de-smoothing route, checker.
Grade: written proof draft + finite checks; NOT independently reviewed; no total-E improvement.

### 5. `prime_pair_sharp_transfer.zip`
Status: NOT committed.
Contents: `SHARP_TRANSFER.md`, proof draft transferring the smoothed annulus estimate to the actual sharp cutoff on a square-root-scale band, checker and manifest.
Grade: written proof draft + checks; NOT independently reviewed; restricted component improvement only.

### 6. `prime_pair_multiscale.zip`
Status: NOT committed.
Contents: `MULTISCALE.md`, variable-T sharp-frequency estimates using published zero-additive-energy bounds, rational-region accounting, central localization inequality, checker.
Grade: written proof draft + checks; NOT independently reviewed; no improved total-E bound.

### 7. `central_arithmetic_attack.zip`
Status: NOT committed.
Contents: `DIRECT_ATTACK.md`, exact divisor/factorization attack on the central prime-counting obstruction, explicit zeta-mode cancellation calculation, counterfeit coarse-statistics model, checker.
Grade: direct attack / obstruction analysis; no improved RH bound.

### 8. `source_text/Pasted text(20260906-113217).txt`
Status: source transcript of the independent referee report for the Wronskian/A-B branch.
Important: PR #189 was observed closed/unmerged. This text therefore must not be discarded on the assumption that all referee repairs are in main.

### 9. `source_text/Pasted markdown(20260906-053851).md`
Status: source material for the Möbius-cancellation branch.

## Recommended repository integration

Do this FIRST, before launching new frontier agents.

Create one preservation branch/PR against `zeta-lab/main`, with two goals:

1. Preserve the new prime-pair frontier drafts under the existing hunt, clearly marked unreviewed:
   - `hunts/prime_pair_error/frontier/2026-09-06/FEASIBILITY.md`
   - `hunts/prime_pair_error/frontier/2026-09-06/SHARP_TRANSFER.md`
   - `hunts/prime_pair_error/frontier/2026-09-06/MULTISCALE.md`
   - `hunts/prime_pair_error/frontier/2026-09-06/DIRECT_ATTACK.md`
   - their checker scripts / JSON results / requirements / manifests
   - one `README.md` explaining chronology, status, and that none improves total E yet.

2. Preserve or re-apply the independent referee corrections from PR #189 / referee text if they are not actually present on main. Verify by diff; do not blindly replay.

Keep the Möbius and initial reverse-engineering work separate from `prime_pair_error`:
- either create bounded hunts for them,
- or preserve them under an explicitly noncanonical archive/precursor directory pending curation.
Do NOT dump them into `RESULTS.md` as if they were part of the CHHL proof chain.

Update `MISSION.md` only enough to remove any stale statement that the entire hunt “does not bear on RH”: the first three passes are separate, while `UPPER_BOUND.md` explicitly studies a CHHL criterion whose successful near-quadratic bound would imply RH.

## Next mathematical frontier

Immediate blocker:
Prove an unconditional arithmetic upper bound excluding a coherent prime-counting surplus
`R(N)=psi(N)-N` larger than roughly `N^(1/2+epsilon)`.

Current direct-attack lesson:
- coarse density / positivity / second moments are insufficient;
- exact aggregate factorization identities suppress zeta-zero-shaped modes rather than controlling them;
- zero-energy estimates can control many-zero interactions but do not alone rule out one dangerous off-line zero.

The next research should attack that central coherent mode directly, while retaining the total-E accounting as the canonical RH route.

## Tooling recommendation

- **Zeta Lab**: canonical mathematics, tests, proof drafts, Lean, ball arithmetic, negative controls.
- **Codex directly in Zeta Lab**: first choice for the preservation PR and precise repo integration.
- **Ostoyae**: use AFTER preservation, as the dynamic DAG runner for parallel frontier probes / reviewers / formalizers. Point its pursuit repo at `zeta-lab`.
- **Fulcrum**: operating surface / provenance / allocation. Do not put public mathematics there. Ostoyae is the newer dynamic graph engine described as Fulcrum v2; do not run two competing orchestration systems for the same frontier.

## Suggested next Ostoyae graph after preservation

Parallel root nodes:
1. `central-mode-proof`: attack the one-sided upper bound on `R(N)` without assuming RH.
2. `central-explicit-formula`: derive the sharp central term in zero language; isolate the exact single-zero contribution and every remainder.
3. `arithmetic-separator`: identify exact arithmetic constraints satisfied by Lambda but violated by the counterfeit model, and test which constraints see zeta-zero modes instead of annihilating them.
4. `frontier-referee`: independently review FEASIBILITY / SHARP_TRANSFER / MULTISCALE / DIRECT_ATTACK before any is promoted.

Judge nodes should verify any proposed lemma before it becomes a dependency. Formalization/Lean is downstream, after a stable analytic lemma exists.

## SHA-256 inventory
- `artifacts/prime_reverse_engineering_bundle.zip` — 533979 bytes — `d86eef0cb19e0ab50cd2fddfdda5f64198ba947a1d30cdad03cee49a8ad571c1`
- `artifacts/prime_mobius_review_bundle.zip` — 9647 bytes — `b51b83d6ebe99fbea44efca292d069b882e324bf2824f73150f01038a7052334`
- `artifacts/prime_pair_q3_followup.zip` — 9570 bytes — `2bc81ac5fd7d66370025801d9c06486ded68a8ade2e8dd7d87888f423c9abffb`
- `artifacts/zero_energy_feasibility.zip` — 11822 bytes — `6b690a90c35c886ca5309d4341656aec05fdfc8681223cec484fde403a310ec1`
- `artifacts/prime_pair_sharp_transfer.zip` — 16545 bytes — `aea9833f71b7b0df8e18107e584d42365d98fddab04f152b440fa0bcb4284c83`
- `artifacts/prime_pair_multiscale.zip` — 16675 bytes — `78ba9ae1f6141100ccb96577ceef59467c600daef075522a5fe7b2038e13e09f`
- `artifacts/central_arithmetic_attack.zip` — 12437 bytes — `a5fbd9de8ad3b9f0f71fed0f7abec7ade426128179c99bfad43cbe898489086a`
- `source_text/Pasted markdown(20260906-053851).md` — 15592 bytes — `bfa176325d952ed4bba1941233e47441da8ba97fdeacb295782bb2e265b6531f`
- `source_text/Pasted text(20260906-113217).txt` — 36410 bytes — `edf444d60c619377d1a98d16a0d24b77ae9b15100df1b87c070fed63d5a65251`
