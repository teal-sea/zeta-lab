# Joint candidate: recheck and handoff clarification

This is a verification pass on the previously supplied candidate, not a new candidate or an independent external referee report. The original ZIP and source files are unchanged.

## Files and reproduction

Original ZIP: `joint_correction_candidate.zip`, 13,746 bytes.
SHA-256: `828a4d85d471b51331b5f0a32c30818ccff4de95e9e4c91dbb836536376e8260`.
The original ZIP has exactly three files (JOINT_CORRECTION.md, joint_correction.py, joint_results.json), not an embedded hash manifest. Its ZIP CRC checks pass. This SHA-256 is now the external fingerprint to pin.

Pinned baseline: `teal-sea/zeta-lab` commit `9ec3b6b3b86c25e256ce605f5116fbda3cbc7689`, directory `hunts/prime_pair_error/frontier/2026-09-06/certificate_route_test/`. The Git blob identities of the three actual inputs (refine.py, inputs.json, aggregate_results.json) were fetched from GitHub and matched with the local bytes used for this recheck. They are recorded in independent_checks.json.

The unchanged script was executed from a scratch directory recreating that baseline layout. It completed with exit status 0. Its rerun JSON is byte-identical to the supplied joint_results.json, including all selected rational coefficients, constants, intervals and comparisons. The original output was not overwritten. Wall time was 6.77 seconds with about 852 MiB peak RSS in this environment.

The script uses Path.cwd() as the repository root. Run it from the Zeta Lab ROOT, not from the extracted package directory. After extraction, an example command from that root is:

```sh
.venv/bin/python "$HOME/Downloads/joint_correction_candidate/joint_correction.py" --output /tmp/joint_rerun_results.json
```

Use the actual extracted script path if it differs. Run results go separately, never over the preserved original.

## Separate data-first check

verify_joint.py imports no candidate or baseline code. It rebuilds the candidate from the recorded rational amplitudes and carries, uses Python integer divisor-increment tables (not numpy floor matrices), and uses mpmath interval logarithms/log-gamma rather than the original rational-log implementation.

- All 662 merged finite coefficients reconstruct exactly; they are balanced.
- Amplitudes and repair weights are positive. Exactly 172 repair cells are used, all within the original 411 allowed cells.
- Finite coefficient mass is 56345/108; tail coefficient is 701/36.
- Both original seed periods pass exact positivity and initial coverage checks.
- All 99,999 nonzero prefix cells have lifted weight at least 1; its minimum is exactly 1. The finite seed is negative at 640 cells, as reported.
- Every candidate masked carry q=13,...,36 has maximum 3 over a verified period of length 210*q*(q+1): 3,390,240 integer cells total. Balance and divisibility prove these enumerated periods are genuine periods, not arbitrary cutoff samples.
- The independently enclosed new C lies below the independently enclosed baseline C. The new interval contains the recorded 80-digit approximation.
- kappa(D) is positive, as needed when upper-bounding the truncated geometric main terms.
- All four B_N and U_N comparisons were recomputed with interval arithmetic. Positive lower endpoints establish each reported improvement, and each B_N is below its own U_N at the tested cutoff.
- 1,397 exact prime-exponent identities at N=1,000 and N=10,000 pass, including final covering weights at every encountered prime-power argument.

## General proof check

Define b_q(t)=floor(t/q)-floor(t/(q+1))-floor(t/(q(q+1))). It equals floor(u+v)-floor(u)-floor(v), with u=t/(q+1), v=t/(q(q+1)). Thus it is 0 or 1 for every integer q>=2; q need not be prime. Dilations preserve nonnegativity. The masked correction may have either sign, but its independently established upper bound is 3.

Write D=g0-sum_q y_q h_q+sum_n lambda_n b_n, and g=D+H W_*(t/R). Below R the tail vanishes, so exact lifted-prefix coverage applies. At and above R, g0>=0, the positive patches are nonnegative, -sum y_q h_q>=-3 sum y_q=-H, and H W_*(t/R)>=H. Therefore g>=0 there. For t>=R the recursion W_g(t)=g(t)+W_g(t/15) reaches [R/15,R), where coverage is already verified. This proves W_g>=1 at all real t>=1; integer breakpoints extend integer checks to entire cells.

D is a bounded balanced finite floor sum, and W_* grows at most logarithmically. Thus g is absolutely integrable against t^-2 dt, justifying interchange with its geometric dilations. The same finite divisor identity yields B_N=sum Lambda(d) W_g(N/d)>=psi(N). This algebraic connection is classical; Bober's arXiv:0709.1977 describes the floor/factorial framework, but does not validate this candidate.

The absolute factorial remainder inequality applies to signed balanced coefficients. The positive kappa(D) and kappa(g_*) permit the favorable geometric-tail truncations. The complete sufficient envelope is

    U_new(N)=C_new*N+(56345/108)*S1(N)+(3505/12)*S2(N),

where the last coefficient is (701/36)*15, NOT 225. The old envelope has coefficients 2641/3 and 225. The supplied script accounts for the increased tail. No claim is made that new U is below old U at EVERY cutoff; four specific comparisons are verified.

## Limitations and correction to the conversational framing

This is a cheaper fixed construction, not a uniform improvement law or RH progress. It does not improve total CHHL E(N), prove LP optimality, determine novelty, or establish a new state-of-the-art prime-counting bound.

The targeted early overcount is only partially reduced. At t=20 the old and new lifted weights are both 3; at t=21 both are 2, and the t=19 value increases. The weighted net cost improves, not every pointwise weight. A repeatable rule for eliminating the remaining excess is still missing.

The candidate awaits Claude's separate written review. PR #199 is the baseline review, not a review of this new candidate. No new GitHub writes, merges, external agent launches, or continuing background research occurred in this verification pass.

## Evidence

`independent_checks.json` gives exact interval endpoints, input Git hashes, every comparison, and counts. `verify_joint.py` is the executed separate checker; its baseline layout is documented above. `rerun_results.json`, `rerun.log`, and `rerun.resources.log` record the unchanged candidate rerun.
