# Prime-pair errors: fixed endpoint and modulo-3 follow-up

## Result

This follow-up independently recomputed the user's prime-pair error ratios at
100,000; 1,000,000; 3,000,000; and 10,000,000. It also evaluated the proposed
endpoint correction WITHOUT fitting its coefficients. A further modulo-3
character correction reduced squared error at every checked cutoff.

This is a numerical investigation of a standard residue-class mechanism.
No claim is made that the finite-window formula is new, proved, pointwise
accurate, or sufficient for the Prime Pair Error Conjecture. The unexplained
squared error remains dominant.

## Definitions and fixed predictions

For positive integer N and even 2 <= k < N, let

    psi2(N,k) = sum_{1 <= n <= N-k} Lambda(n) Lambda(n+k)
    e(N,k) = psi2(N,k) - S(k)(N-k)
    R(x) = sum_{1 <= n <= x} Lambda(n) - x

The existing fixed endpoint correction is

    H0(N,k) = S(k)[R(N) + R(N-k) - R(k)].

Set chi3(n)=0, +1, -1 for n congruent to 0, 1, 2 modulo 3, respectively, and

    T3(x) = sum_{n <= x} Lambda(n) chi3(n).

The additional, fixed-coefficient correction tested here is

    G3(N,k) = -S(k) chi3(k)[T3(N) - T3(k) - T3(N-k)].

Compare e-H0 with e-H0-G3. All multipliers in the predictions are fixed
analytically, not obtained by regression. The posterior diagnostic slope is
listed separately; it is NOT used in either prediction.

The gain metric is

    1 - sum_even (e-H)^2 / sum_even e^2.

It measures reduction of the uncentered squared error over even 2 <= k < N,
not a centered variance and not exact prime prediction. E_normalized in the
JSON includes ALL positive shifts and a factor 2 for positive/negative shifts.
One-point totals R and T3 are measured in the evaluation range: this tests an
explanation of two-point counts from one-point data, not a prime generator.

## Measurements

| N | Existing H0: squared-error reduction | H0 + G3: squared-error reduction | Diagnostic G3 slope |
|---|---:|---:|---:|
| 100,000 | 1.0502% | 2.9123% | 1.008917 |
| 1,000,000 | 2.6345% | 4.9766% | 0.999367 |
| 3,000,000 | 0.3994% | 0.6698% | 1.014344 |
| 10,000,000 | 1.8841% | 2.2999% | 0.998635 |
| 1,234,567 | 0.5936% | 1.1007% | 0.998483 |
| 4,567,891 | 0.4722% | 1.8045% | 1.002020 |
| 12,345,679 | 0.3462% | 0.6073% | 0.998767 |

The final three cutoffs (1,234,567; 4,567,891; 12,345,679) were selected and
written into the computation before their results were computed, after
formulating and inspecting the correction at the four previously reported
scales. The last is beyond the previous 10-million limit. These are cumulative,
overlapping datasets, NOT statistically independent replicates. There is no
formal p-value or significance claim.

## Why the endpoint bracket is already expected

An elementary exact expansion, not a new theorem, is obtained by setting
a(n)=Lambda(n)-1:

    psi2(N,k) = (N-k) + [R(N)+R(N-k)-R(k)]
               + sum_{n=1}^{N-k} a(n)a(n+k).

Thus the bracket itself is already the exact linear contribution. The
nontrivial modeling question is why and in what averaged sense local arithmetic
modifies its coefficient to S(k), and what can be controlled in the remaining
two-point correlation. Writing "+ noise" without specifying a norm, average,
or bound does not answer that question.

## Exact period-6 algebra behind the modulo-3 candidate

This is elementary periodic centering, not a novelty claim.

Let b(n)=3 when gcd(n,6)=1 and b(n)=0 otherwise; set u(n)=Lambda(n)-b(n).
The exact product expansion is

    psi2 = sum b(n)b(n+k)
           + sum [b(n)u(n+k)+u(n)b(n+k)]
           + sum u(n)u(n+k).

All sums have 1 <= n <= N-k. Define

    A+(x) = sum_{n<=x, n=1 mod6} u(n)
    A-(x) = sum_{n<=x, n=5 mod6} u(n)
    U(x) = A+(x)+A-(x)
    V(x) = A+(x)-A-(x).

For even k, set S6(k)=3 when 3 divides k, and S6(k)=3/2 otherwise.
The part of the linear term with BOTH endpoints coprime to 6 is exactly

    S6(k) [ U(N)+U(N-k)-U(k)
            -chi3(k)(V(N)-V(k)-V(N-k)) ].

For example, when k=2 mod6 the allowed unit-to-unit transition is 5 -> 1;
when k=4 mod6 it is 1 -> 5. This gives the opposite signs of the character term.

An exceptional term must also be retained for an EXACT full linear identity.
Put t(n)=Lambda(n) if gcd(n,6)>1, and zero otherwise. Add

    J(N,k) = sum [b(n)t(n+k) + t(n)b(n+k)].

This explicitly accounts for prime powers outside the reduced residue classes.
For even k, powers of 3 can contribute here; parity prevents powers of 2 from
forming such mixed baseline terms. Omitting J is NOT an exact identity.
The checker verifies the full linear identity over all 8,010 even-shift cases
with 3 <= N <= 180; the maximum floating difference is below 3e-14.
Omitting the exceptional term yields discrepancies as large as 26.37 there.

U(x)=R(x)+O(log x), while V(x)=T3(x)+O(1); this follows by accounting for powers
of 2 and 3 and the bounded discrepancy in the counts of the two residue classes.
Replacing S6 with the full S, U with R, V with T3, and treating the explicitly
described lower-order terms separately motivates H0+G3. The replacement and the
smallness of the remaining centered product are HEURISTIC, not consequences of
the exact product expansion.

## Assessment of the user's report

* Table 1's published caption explicitly says truncation to five decimals.
  Independent numerical values in this follow-up agree with four headline
  normalized ratios, including the 10-million value.
* The original `probe.py` re-estimates three regression coefficients at each
  N. This is a useful structural diagnostic, but the fitted explained-error
  percentage is not itself a frozen-coefficient prediction score. The fixed
  checks here support the effect without those fitted coefficients.
* Odd-separation error is negligible at large tested N, not identically zero.
* The observed exponent 0.71, 0.75, 0.79, 0.83 is evidence against a
  scale-independent proportional model in this range; because it moves toward
  1, it does not refute a limiting exponent of 1.
* Equality of psi2-theta2 with the actual prime-power pair contribution is
  exact; approximation of that contribution by S(k)B(N,k) is not.
* Coefficients described as "within a few percent" need an absolute scale near
  R(N)=0. At N=3 million the alpha offset cannot be assessed by a relative
  percentage of the nearly zero R(N).
* "The small-k limit" comparison with Korevaar-te Riele needs their distinct
  cutoff conventions, weight convention, averaging range, and error terms
  retained. Their theta-pair weight is log^2(p), whereas the experiment uses
  log(p)log(p+k). These differ, especially when k is comparable to the cutoff.
* The current measurements do not establish an upper bound on E(N), the limit
  of E(N)/(N^2 log^2 N), or a new-to-literature result.

## Normalization cross-check

The printed Korevaar-te Riele equation (3.4) states

    sum_{r<=m} C_(2r) = m - (1/2)log m + O(log^(2/3)(m+1)).

Under their definition S(2r)=2 C_(2r), that would imply

    sum_{k<=x} S(k) = x - log x + O(log^(2/3)x).

Partial summation would then give a coefficient -1 on x log x in
sum_{k<=x}(x-k)S(k). By contrast, Goldston-Suriajaya (2020), equation (1.4),
uses the same singular series and records the established coefficient -1/2:

    sum_{k<=x}(x-k)S(k)
      = (1/2)x^2 - (1/2)x log x
        + (1/2)(1-gamma-log(2*pi))x + error.

This is a substantive source-normalization inconsistency, beyond a numerical
fit alone. The corresponding coefficient for the C_(2r) sum would be -1/4,
not -1/2. This follow-up did not retrieve the full original 1995
Friedlander-Goldston paper or contact the authors; treat this as a documented
normalization discrepancy rather than a claimed newly discovered corrigendum.

## Next bounded experiment

Derive a single period-30 decomposition, incorporating 2, 3, and 5 together.
Do not simply add separate mod-3 and mod-5 fits: common structure can be counted
twice. Keep the deterministic periodic term, linear residue-class endpoint
terms, exceptional prime-power terms, and centered-product remainder explicit.
Distinguish exact identities from any replacement by the full singular series.

Evaluate a derived fixed-coefficient predictor at fresh cutoffs before fitting
anything there. Compare the original endpoint correction, the mod-3 correction,
and the mod-30-derived version. Report global squared-error gain and
residue-class/block errors, not independent-observation significance estimates.
The target is an explanation of an additional residual component and an
explicit remainder to study, not a bigger infrastructure project.

## Reproduction and provenance

Files:
- `verify_q3.py`: independent implementation; numpy and scipy only.
- `check_period6.py`: separate exact-linear-decomposition checker.
- `results.json`: every measured score and independent headline checks.
- `requirements.txt`.

Run:

    python -m pip install -r requirements.txt
    OPENBLAS_NUM_THREADS=1 python verify_q3.py --N 100000 1000000
    python check_period6.py

All seven recorded cutoffs:

    OPENBLAS_NUM_THREADS=1 python verify_q3.py \
      --N 100000 1000000 3000000 10000000 1234567 4567891 12345679

Repository files inspected:
- https://github.com/teal-sea/zeta-lab/blob/main/hunts/prime_pair_error/RESULTS.md
  Blob SHA: 8aead7277926e5df45bb739fdf3d32370699bb9c
- https://github.com/teal-sea/zeta-lab/blob/main/hunts/prime_pair_error/probe.py
  Blob SHA: f315cc27943ba14514a06f0705176915800b1fa3

External primary sources checked:
- Chou, Haag, Huryn, Ledoan, https://arxiv.org/abs/2308.14888
- Korevaar and te Riele, https://arxiv.org/abs/0902.4352
- Final journal version: https://ir.cwi.nl/pub/16871/16871A.pdf
- Goldston and Suriajaya, https://arxiv.org/abs/2007.16099

The independent script was created in the chat workspace; no GitHub files
were modified.
