#!/usr/bin/env python3
"""Verify an unpacked research checkpoint. This checks bytes, not mathematics."""
from __future__ import annotations
import argparse, hashlib, io, json, sys, zipfile
from pathlib import Path, PurePosixPath

EXPECTED_ARCHIVES = {
    'prime_reverse_engineering_bundle.zip', 'prime_mobius_review_bundle.zip',
    'prime_pair_q3_followup.zip', 'zero_energy_feasibility.zip',
    'prime_pair_sharp_transfer.zip', 'prime_pair_multiscale.zip',
    'central_arithmetic_attack.zip', 'zeta_frontier_handoff_2026-09-06.zip',
    'factorial_certificate_pilot.zip', 'certificate_structural_step.zip',
    'certificate_refinement_rule.zip', 'certificate_route_test.zip',
}
class IntegrityError(ValueError): pass

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def safe_relative(name: str) -> Path:
    p=PurePosixPath(name)
    if p.is_absolute() or not p.parts or '..' in p.parts or '\\' in name:
        raise IntegrityError(f'Unsafe relative path: {name}')
    return Path(*p.parts)

def verify(root: Path) -> dict:
    root=root.resolve()
    manifest_path=root/'CHECKPOINT_MANIFEST.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    records=manifest.get('files')
    if not isinstance(records,list) or not records:
        raise IntegrityError('Missing or empty checkpoint manifest')
    seen=set()
    for r in records:
        name=r['path']
        if name in seen: raise IntegrityError(f'Duplicate manifest member: {name}')
        seen.add(name)
        path=root/safe_relative(name)
        if path.is_symlink() or not path.is_file(): raise IntegrityError(f'Missing/unsafe file: {name}')
        data=path.read_bytes()
        if len(data)!=r['bytes'] or digest(data)!=r['sha256']:
            raise IntegrityError(f'Byte/hash mismatch: {name}')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()
            and '__pycache__' not in p.parts}
    if actual != seen|{'CHECKPOINT_MANIFEST.json'}:
        raise IntegrityError(f'Unlisted/missing files: {sorted(actual.symmetric_difference(seen|{"CHECKPOINT_MANIFEST.json"}))}')
    inventory=json.loads((root/'ARCHIVE_INVENTORY.json').read_text())
    archives=inventory.get('archives',[])
    if {Path(r['path']).name for r in archives}!=EXPECTED_ARCHIVES or len(archives)!=12:
        raise IntegrityError('Archive inventory is incomplete or duplicated')
    total_members=0
    for r in archives:
        path=root/safe_relative(r['path']); data=path.read_bytes()
        if not data or digest(data)!=r['sha256'] or len(data)!=r['bytes']:
            raise IntegrityError(f'Archive mismatch: {path.name}')
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if z.testzip() is not None: raise IntegrityError(f'CRC mismatch: {path.name}')
            names=[i.filename for i in z.infolist() if not i.is_dir()]
            required=r.get('members',[])
            if not required or len(names)!=len(set(names)) or set(names)!={x['path'] for x in required}:
                raise IntegrityError(f'Invalid ZIP membership: {path.name}')
            for member in required:
                safe_relative(member['path'])
                b=z.read(member['path'])
                if len(b)!=member['bytes'] or digest(b)!=member['sha256']:
                    raise IntegrityError(f'Member mismatch: {path.name}:{member["path"]}')
                total_members+=1
    if total_members!=inventory['member_count']: raise IntegrityError('Member count mismatch')
    return {'status':'PASS','files':len(records),'original_archives':len(archives),'direct_archive_members':total_members,
            'scope':'Byte integrity only; no new mathematical validation or GitHub import implied.'}

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',nargs='?',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args()
    try: result=verify(args.directory)
    except (IntegrityError,OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as e:
        print(f'FAIL: {e}',file=sys.stderr); return 1
    print(json.dumps(result,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
